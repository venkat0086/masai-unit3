let navbar = () => {
  return `<div id="navbar">
    <h3>Home</h3>

    <div id="options">
      <h3><a href="electronics.html">Electronics</a></h3>
      <h3><a href="jewellery.html">Jewellery</a></h3>
      <h3><a href="">Sign In</a></h3>
      <h3><a href="">Sign Up</a></h3>
    </div>
  </div>`;
};

export default navbar;
