function gotoMenu() {
  window.location.href = "menu.html";
}
function gotoCart() {
  window.location.href = "cart.html";
}
function gotoAddress() {
  window.location.href = "checkout.html";
}
